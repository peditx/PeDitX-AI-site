import React, { useState } from 'react';
import { Menu, X, ArrowRight } from 'lucide-react';

interface NavbarProps {
  onNavigate: (section: 'projects' | 'blog' | 'about' | 'resume' | 'apply') => void;
  activeSection?: string;
}

export const Navbar: React.FC<NavbarProps> = ({ onNavigate, activeSection }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'projects', label: 'PROJECTS', href: 'https://peditx.ir' },
    { id: 'peditxos', label: 'PEDITXOS', href: 'https://peditxos.ir' },
    { id: 'about', label: 'ABOUT', href: 'https://peditx.ir' },
    { id: 'github', label: 'GITHUB', href: 'https://github.com/peditx' },
  ] as const;

  const handleLinkClick = (id: 'projects' | 'blog' | 'about' | 'resume') => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <>
      <header className="absolute top-0 left-0 right-0 z-40 w-full px-6 md:px-12 py-7 flex items-center justify-between border-b border-white/5 backdrop-blur-[2px]">
        {/* White Minimalist Logo */}
        <div className="flex items-center gap-3">
          <a
            href="#home"
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-2.5 group cursor-pointer"
            aria-label="PeDitX-Ai Home"
          >
            {/* Minimalist white geometric nest mark */}
            <div className="w-8 h-8 rounded-lg border border-white/30 flex items-center justify-center bg-white/[0.04] group-hover:border-[#5ed29c] group-hover:bg-[#5ed29c]/10 transition-all duration-300">
              <svg
                className="w-4 h-4 text-white group-hover:text-[#5ed29c] transition-colors"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="m7 8-4 4 4 4" />
                <path d="m17 8 4 4-4 4" />
                <path d="m14 4-4 16" />
              </svg>
            </div>
            <span className="font-['Inter'] font-bold text-xl md:text-2xl tracking-tight text-white group-hover:text-white transition-colors">
              PeDitX-Ai<span className="text-[#5ed29c]">.</span>
            </span>
          </a>
        </div>

        {/* Desktop Menu: Links in Inter, 16px, Hover state: #5ed29c */}
        <nav
          className="hidden md:flex items-center gap-9"
          aria-label="Main Navigation"
        >
          {navLinks.map((item) => (
            <a
              key={item.id}
              href={item.href}
              target="_blank"
              rel="noopener noreferrer"
              className="font-['Inter'] text-[16px] font-medium tracking-wide text-white/90 hover:text-[#5ed29c] transition-colors py-1 relative group"
            >
              <span>{item.label}</span>
              <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#5ed29c] scale-x-0 group-hover:scale-x-100 transition-transform origin-left rounded-full" />
            </a>
          ))}
        </nav>

        {/* Desktop Right CTA Pill */}
        <div className="hidden md:flex items-center gap-4">
          <button
            onClick={() => onNavigate('apply')}
            className="font-['Inter'] text-xs font-semibold uppercase tracking-wider text-[#5ed29c] hover:text-[#070b0a] border border-[#5ed29c]/50 hover:bg-[#5ed29c] px-4 py-2 rounded-full transition-all duration-200 cursor-pointer shadow-[0_0_15px_rgba(94,210,156,0.15)]"
          >
            Quick Install
          </button>
        </div>

        {/* Mobile Menu Trigger (Hamburger) */}
        <div className="flex md:hidden items-center">
          <button
            onClick={() => setMobileMenuOpen(true)}
            className="p-2 text-white hover:text-[#5ed29c] transition-colors cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#5ed29c]"
            aria-label="Open mobile menu"
            aria-expanded={mobileMenuOpen}
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </header>

      {/* Full-screen Dark Overlay Mobile Menu */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-50 bg-[#070b0a]/95 backdrop-blur-xl flex flex-col justify-between p-8 md:hidden animate-in fade-in duration-200"
          role="dialog"
          aria-modal="true"
        >
          <div className="flex items-center justify-between border-b border-white/10 pb-6">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg border border-white/30 flex items-center justify-center bg-white/[0.04]">
                <span className="text-white font-mono text-sm font-bold">&lt;/&gt;</span>
              </div>
              <span className="font-['Inter'] font-bold text-xl tracking-tight text-white">
                PeDitX-Ai<span className="text-[#5ed29c]">.</span>
              </span>
            </div>
            <button
              onClick={() => setMobileMenuOpen(false)}
              className="p-2 text-white/80 hover:text-white hover:rotate-90 transition-all cursor-pointer rounded-lg border border-white/10"
              aria-label="Close mobile menu"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="flex flex-col gap-6 py-12">
            {navLinks.map((item, idx) => (
              <a
                key={item.id}
                href={item.href}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setMobileMenuOpen(false)}
                className="text-left font-['Inter'] text-2xl font-bold tracking-tight text-white hover:text-[#5ed29c] flex items-center justify-between group transition-colors py-2"
                style={{ animationDelay: `${idx * 50}ms` }}
              >
                <span>{item.label}</span>
                <span className="text-xs font-mono text-white/40 group-hover:text-[#5ed29c] transition-colors">
                  0{idx + 1}
                </span>
              </a>
            ))}
          </div>

          <div className="pt-6 border-t border-white/10 flex flex-col gap-4">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onNavigate('apply');
              }}
              className="w-full rounded-full bg-[#5ed29c] text-[#070b0a] font-['Inter'] font-bold text-sm uppercase py-4 flex items-center justify-center gap-2 hover:bg-[#72e4af] transition-all cursor-pointer"
            >
              <span>Install PeDitX-Ai</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <p className="text-center text-xs text-white/40 font-mono">
              [ PEDITXOS &amp; GNOME LINUX READY ]
            </p>
          </div>
        </div>
      )}
    </>
  );
};
