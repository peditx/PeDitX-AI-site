import React from 'react';

interface LiquidGlassCardProps {
  className?: string;
  onClick?: () => void;
}

export const LiquidGlassCard: React.FC<LiquidGlassCardProps> = ({ className = '', onClick }) => {
  return (
    <div
      onClick={onClick}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      className={`liquid-glass-card translate-y-[-50px] p-5 flex flex-col justify-between select-none cursor-pointer group transition-all duration-300 hover:scale-[1.03] hover:shadow-[0_8px_32px_rgba(94,210,156,0.12),inset_0_1px_2px_rgba(255,255,255,0.25)] ${className}`}
      style={{
        width: '200px',
        height: '200px',
      }}
      aria-label="PeDitX-Ai: Taught by Industry Professionals"
    >
      {/* Top row: [ 2026 ] tag (14px) */}
      <div className="flex items-center justify-between">
        <span className="font-mono text-[14px] font-semibold tracking-wider text-[#5ed29c] group-hover:text-white transition-colors">
          [ 2026 ]
        </span>
        <span className="w-1.5 h-1.5 rounded-full bg-[#5ed29c] opacity-80 group-hover:scale-125 transition-transform" />
      </div>

      {/* Middle row: Headline (18px) with Instrument Serif italic */}
      <div className="my-auto">
        <h3 className="font-inter text-[18px] font-semibold leading-[1.25] text-white tracking-tight">
          Driven by{' '}
          <span className="font-instrument-serif italic font-normal text-[22px] text-[#5ed29c] tracking-normal">
            Intelligent
          </span>{' '}
          Agents
        </h3>
      </div>

      {/* Bottom row: Small description (11px) */}
      <div className="pt-1">
        <p className="font-inter text-[11px] leading-tight text-white/70 group-hover:text-white/90 transition-colors">
          Unified OpenWrt router firmware &amp; GNOME Linux automation.
        </p>
      </div>
    </div>
  );
};
