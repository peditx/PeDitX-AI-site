import React, { useEffect, useRef, useState } from 'react';
import Hls from 'hls.js';
import { Volume2, VolumeX, Pause, Play } from 'lucide-react';

interface BackgroundVideoProps {
  onVideoReady?: () => void;
}

export const BackgroundVideo: React.FC<BackgroundVideoProps> = ({ onVideoReady }) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [isMuted, setIsMuted] = useState(true);
  const [isPlaying, setIsPlaying] = useState(true);
  const [streamLoaded, setStreamLoaded] = useState(false);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    let hls: Hls | null = null;
    const videoSrc = 'https://stream.mux.com/tLkHO1qZoaaQOUeVWo8hEBeGQfySP02EPS02BmnNFyXys.m3u8';

    if (Hls.isSupported()) {
      hls = new Hls({
        enableWorker: false, // Explicitly false as required for sandboxed stability
        autoStartLoad: true,
        lowLatencyMode: true,
      });

      hls.loadSource(videoSrc);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        setStreamLoaded(true);
        onVideoReady?.();
        video.play().catch(() => {
          // If autoplay fails, ensure muted and retry
          video.muted = true;
          setIsMuted(true);
          video.play().catch(() => {});
        });
      });

      hls.on(Hls.Events.ERROR, (_event, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              hls?.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              hls?.recoverMediaError();
              break;
            default:
              hls?.destroy();
              break;
          }
        }
      });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      // Native Apple HLS fallback (Safari/iOS)
      video.src = videoSrc;
      video.addEventListener('loadedmetadata', () => {
        setStreamLoaded(true);
        onVideoReady?.();
        video.play().catch(() => {});
      });
    }

    return () => {
      if (hls) {
        hls.destroy();
      }
    };
  }, [onVideoReady]);

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (isPlaying) {
      video.pause();
      setIsPlaying(false);
    } else {
      video.play().then(() => setIsPlaying(true)).catch(() => {});
    }
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  return (
    <div className="absolute inset-0 w-full h-full overflow-hidden pointer-events-none select-none bg-[#070b0a]">
      {/* 1. HLS Video Stream at 60% opacity */}
      <video
        ref={videoRef}
        autoPlay
        muted={isMuted}
        loop
        playsInline
        className="absolute inset-0 w-full h-full object-cover opacity-60 pointer-events-none transition-opacity duration-1000"
        style={{ filter: 'brightness(0.92) contrast(1.08)' }}
      />

      {/* Fallback dark mesh pattern while loading */}
      {!streamLoaded && (
        <div className="absolute inset-0 bg-[#070b0a] transition-opacity duration-700" />
      )}

      {/* 2. Overlays: Dark linear gradient from the left (#070b0a to transparent) */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'linear-gradient(90deg, #070b0a 0%, rgba(7, 11, 10, 0.88) 25%, rgba(7, 11, 10, 0.55) 55%, transparent 100%)'
        }}
      />

      {/* 2b. Bottom-up gradient for readability */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'linear-gradient(0deg, #070b0a 0%, rgba(7, 11, 10, 0.85) 30%, rgba(7, 11, 10, 0.4) 65%, transparent 100%)'
        }}
      />

      {/* 3. Grid System: Three thin vertical grid lines (white/10 opacity) at 25%, 50%, and 75% marks (desktop only) */}
      <div className="hidden lg:block absolute inset-0 pointer-events-none z-10" aria-hidden="true">
        <div className="absolute top-0 bottom-0 left-[25%] w-[1px] bg-white/10" />
        <div className="absolute top-0 bottom-0 left-[50%] w-[1px] bg-white/10" />
        <div className="absolute top-0 bottom-0 left-[75%] w-[1px] bg-white/10" />
      </div>

      {/* 4. Central Glow: Large horizontal SVG ellipse glow in the center-top area with cyan/dark green hue, using 25px Gaussian blur */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-[1300px] h-[480px] pointer-events-none z-10 overflow-visible flex justify-center">
        <svg
          className="w-full h-full overflow-visible"
          viewBox="0 0 1000 400"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          aria-hidden="true"
        >
          <defs>
            <filter id="central-glow-blur" x="-40%" y="-40%" width="180%" height="180%">
              <feGaussianBlur stdDeviation="25" />
            </filter>
            <radialGradient id="cyan-green-radial" cx="50%" cy="30%" r="55%" fx="50%" fy="25%">
              <stop offset="0%" stopColor="#5ed29c" stopOpacity="0.45" />
              <stop offset="30%" stopColor="#1fe093" stopOpacity="0.30" />
              <stop offset="60%" stopColor="#083e2e" stopOpacity="0.18" />
              <stop offset="90%" stopColor="#070b0a" stopOpacity="0.02" />
              <stop offset="100%" stopColor="#070b0a" stopOpacity="0" />
            </radialGradient>
          </defs>
          <ellipse
            cx="500"
            cy="110"
            rx="460"
            ry="110"
            fill="url(#cyan-green-radial)"
            filter="url(#central-glow-blur)"
          />
        </svg>
      </div>

      {/* Subtle Stream HUD Controller (Pointer events allowed for this discreet control) */}
      <div className="absolute bottom-6 right-6 z-20 pointer-events-auto hidden sm:flex items-center gap-2 bg-[#070b0a]/75 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10 text-[11px] text-white/60 font-mono">
        <span className="w-1.5 h-1.5 rounded-full bg-[#5ed29c] animate-pulse" />
        <span className="text-white/80">MUX HLS LIVE</span>
        <span className="text-white/30">|</span>
        <button
          onClick={togglePlay}
          className="hover:text-white transition-colors cursor-pointer p-1"
          title={isPlaying ? "Pause background stream" : "Play background stream"}
          aria-label={isPlaying ? "Pause video" : "Play video"}
        >
          {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
        </button>
        <button
          onClick={toggleMute}
          className="hover:text-white transition-colors cursor-pointer p-1"
          title={isMuted ? "Unmute stream" : "Mute stream"}
          aria-label={isMuted ? "Unmute audio" : "Mute audio"}
        >
          {isMuted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
        </button>
      </div>
    </div>
  );
};
