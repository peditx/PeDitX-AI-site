import React from 'react';
import { ArrowRight, Play, Terminal, ShieldCheck, Cpu } from 'lucide-react';
import { LiquidGlassCard } from './LiquidGlassCard.tsx';

interface HeroSectionProps {
  onGetStarted: () => void;
  onExploreProjects: () => void;
  onCardClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onGetStarted,
  onExploreProjects,
  onCardClick,
}) => {
  return (
    <div className="relative z-20 min-h-screen flex flex-col justify-between pt-36 sm:pt-40 md:pt-44 pb-12 px-6 sm:px-10 lg:px-16 max-w-7xl mx-auto w-full">
      {/* Main Hero Column / Content Area */}
      <div className="flex-1 flex flex-col justify-center items-start">
        {/* 
          Specification 2: The Liquid Glass Card
          200x200px floating card positioned above the main headline, shifted exactly 50px upwards using translate-y-[-50px]
        */}
        <div className="relative z-30 mb-1">
          <LiquidGlassCard onClick={onCardClick} />
        </div>

        {/* Eyebrow */}
        <div className="font-['Plus_Jakarta_Sans'] font-bold text-[11px] uppercase tracking-[0.22em] text-[#5ed29c] mb-4 flex items-center gap-2 select-none">
          <span>Intelligent OS &amp; Network Automation</span>
        </div>

        {/* 
          Main Headline:
          'CONTROL YOUR OS WITH AI.' in Inter Extra Bold, uppercase, tracking-tight.
          Scale from 40px (mobile) to 72px (desktop). The final period must be green (#5ed29c).
        */}
        <h1 className="font-['Inter'] font-extrabold uppercase tracking-tight text-[40px] sm:text-[54px] lg:text-[72px] leading-[1.02] text-white max-w-4xl mb-6 select-text text-balance">
          CONTROL YOUR OS WITH AI<span className="text-[#5ed29c]">.</span>
        </h1>

        {/* Description: 14px Inter, 70% opacity, max-width 512px */}
        <p className="font-['Inter'] text-[14px] leading-relaxed text-white/70 max-w-[512px] mb-9 select-text">
          Next-generation AI orchestration for PeDitXOS (OpenWrt) routers and GNOME Linux systems. Monitor live kernel telemetry, automate routing policies, and control your entire operating system through natural-language directives.
        </p>

        {/* Primary CTA & Secondary Action */}
        <div className="flex flex-wrap items-center gap-4 sm:gap-6">
          <button
            onClick={onGetStarted}
            className="rounded-full bg-[#5ed29c] text-[#070b0a] font-['Inter'] font-bold text-xs sm:text-sm uppercase tracking-wider px-8 py-4 flex items-center gap-2.5 hover:bg-[#72e4af] transition-all duration-200 hover:scale-[1.02] active:scale-95 shadow-[0_0_28px_rgba(94,210,156,0.32)] cursor-pointer group"
            aria-label="Install PeDitX-Ai"
          >
            <span>Install PeDitX-Ai</span>
            <ArrowRight className="w-4 h-4 stroke-[2.5] group-hover:translate-x-0.5 transition-transform" />
          </button>

          {/* Secondary Action: Direct PeDitXOS Documentation Link */}
          <a
            href="https://peditxos.ir"
            target="_blank"
            rel="noopener noreferrer"
            className="font-['Inter'] text-xs sm:text-sm font-semibold tracking-wide text-white/80 hover:text-white flex items-center gap-2 px-5 py-3.5 rounded-full border border-white/10 hover:border-white/30 bg-white/[0.02] hover:bg-white/[0.05] transition-all duration-200 cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 text-[#5ed29c] fill-[#5ed29c]" />
            <span>PeDitXOS Router Docs</span>
          </a>
        </div>
      </div>

      {/* Trust & System Ecosystem Benchmark Strip */}
      <div className="mt-16 pt-8 border-t border-white/10 w-full flex flex-col md:flex-row md:items-center justify-between gap-6 text-white/50">
        <div className="flex items-center gap-3">
          <span className="font-['Plus_Jakarta_Sans'] text-xs font-semibold uppercase tracking-wider text-white/40">
            Supported Environments
          </span>
          <span className="hidden sm:inline text-white/20">|</span>
          <div className="flex items-center gap-5 sm:gap-7 text-xs font-mono font-medium tracking-wide text-white/70">
            <span className="hover:text-white transition-colors">PEDITXOS</span>
            <span className="hover:text-white transition-colors">OPENWRT</span>
            <span className="hover:text-white transition-colors">GNOME LINUX</span>
            <span className="hover:text-white transition-colors">WIREGUARD</span>
            <span className="hover:text-white transition-colors">EBPF</span>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono text-white/60">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-[#5ed29c]" />
            <span>Root Isolation</span>
          </div>
          <span className="text-white/20">·</span>
          <div className="flex items-center gap-1.5">
            <Terminal className="w-3.5 h-3.5 text-[#5ed29c]" />
            <span>Real-Time Telemetry</span>
          </div>
        </div>
      </div>
    </div>
  );
};
