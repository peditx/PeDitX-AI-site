import React, { useState } from 'react';
import { X, Check, Copy, Terminal, ExternalLink, Store, CheckCircle2, ChevronRight, Globe, Shield } from 'lucide-react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  type?: 'get_started' | 'projects' | 'blog' | 'about' | 'resume' | 'liquid_card' | null;
}

export const InteractiveModals: React.FC<ModalProps> = ({ isOpen, onClose }) => {
  const [platform, setPlatform] = useState<'openwrt' | 'gnome'>('openwrt');
  const [copied, setCopied] = useState(false);
  const [copyMethod, setCopyMethod] = useState<'curl' | 'wget'>('curl');

  if (!isOpen) return null;

  const gnomeCommands = {
    curl: 'curl -fsSL https://peditx.ir/ai/linux-install.sh | sudo bash',
    wget: 'wget -qO- https://peditx.ir/ai/linux-install.sh | sudo bash',
  };

  const currentGnomeCommand = gnomeCommands[copyMethod];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-[#070b0a]/85 backdrop-blur-md transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Modal Card */}
      <div
        className="relative z-10 w-full max-w-2xl bg-[#0c1311] border border-white/10 rounded-2xl shadow-[0_24px_64px_rgba(0,0,0,0.8),0_0_40px_rgba(94,210,156,0.12)] overflow-hidden text-white my-8 max-h-[92vh] flex flex-col"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-[#090f0d]">
          <div className="flex items-center gap-2.5">
            <span className="w-2 h-2 rounded-full bg-[#5ed29c] animate-pulse" />
            <span className="font-mono text-xs text-[#5ed29c] font-semibold tracking-wider uppercase">
              PeDitX-Ai · Installation Guide
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/60 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-7 overflow-y-auto space-y-6">
          {/* Target Environment Tabs */}
          <div>
            <label className="block text-xs font-['Inter'] font-semibold uppercase tracking-wider text-white/70 mb-2.5">
              Select Your Target Environment
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* PeDitXOS Tab */}
              <button
                type="button"
                onClick={() => setPlatform('openwrt')}
                className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                  platform === 'openwrt'
                    ? 'border-[#5ed29c] bg-[#5ed29c]/10 text-white shadow-[0_0_16px_rgba(94,210,156,0.15)]'
                    : 'border-white/10 bg-white/[0.02] text-white/60 hover:border-white/20 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${platform === 'openwrt' ? 'bg-[#5ed29c] text-[#070b0a]' : 'bg-white/10 text-white'}`}>
                    <Store className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-['Inter'] font-bold text-sm">PeDitXOS (OpenWrt)</div>
                    <div className="font-mono text-[11px] text-[#5ed29c]">PeDitXOS Store</div>
                  </div>
                </div>
                {platform === 'openwrt' && <CheckCircle2 className="w-4 h-4 text-[#5ed29c]" />}
              </button>

              {/* GNOME Linux Tab */}
              <button
                type="button"
                onClick={() => setPlatform('gnome')}
                className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                  platform === 'gnome'
                    ? 'border-[#5ed29c] bg-[#5ed29c]/10 text-white shadow-[0_0_16px_rgba(94,210,156,0.15)]'
                    : 'border-white/10 bg-white/[0.02] text-white/60 hover:border-white/20 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${platform === 'gnome' ? 'bg-[#5ed29c] text-[#070b0a]' : 'bg-white/10 text-white'}`}>
                    <Terminal className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-['Inter'] font-bold text-sm">GNOME Linux</div>
                    <div className="font-mono text-[11px] text-[#5ed29c]">Automated Install Script</div>
                  </div>
                </div>
                {platform === 'gnome' && <CheckCircle2 className="w-4 h-4 text-[#5ed29c]" />}
              </button>
            </div>
          </div>

          {/* Platform Specific Installation Details */}
          {platform === 'openwrt' ? (
            /* PeDitXOS Section: Installed strictly through the internal PeDitXOS Store GUI */
            <div className="space-y-4">
              <div className="p-4 rounded-xl border border-[#5ed29c]/30 bg-[#5ed29c]/5">
                <div className="flex items-start gap-3">
                  <Store className="w-5 h-5 text-[#5ed29c] shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-['Inter'] font-bold text-sm text-white mb-1">
                      Direct Installation via PeDitXOS Store
                    </h3>
                    <p className="font-['Inter'] text-xs text-white/70 leading-relaxed">
                      On PeDitXOS, installation is exclusively handled through the built-in <strong>PeDitXOS Store</strong> inside your router's administration web panel. No manual terminal commands or external packages are required.
                    </p>
                  </div>
                </div>
              </div>

              {/* Step by Step Visual Guide */}
              <div className="space-y-2.5">
                <span className="block text-xs font-['Inter'] font-semibold uppercase tracking-wider text-white/70">
                  How to Install on PeDitXOS:
                </span>

                <div className="p-3.5 rounded-xl border border-white/10 bg-white/[0.02] flex items-center gap-3 text-xs">
                  <span className="font-mono font-bold text-xs px-2.5 py-1 rounded bg-white/10 text-[#5ed29c]">
                    STEP 01
                  </span>
                  <span className="text-white/85">
                    Open your router's web panel by navigating to <code className="font-mono text-[#5ed29c] bg-white/5 px-1.5 py-0.5 rounded">192.168.1.1</code> (or your gateway address) in your browser.
                  </span>
                </div>

                <div className="p-3.5 rounded-xl border border-white/10 bg-white/[0.02] flex items-center gap-3 text-xs">
                  <span className="font-mono font-bold text-xs px-2.5 py-1 rounded bg-white/10 text-[#5ed29c]">
                    STEP 02
                  </span>
                  <span className="text-white/85">
                    Navigate to <strong>PeDitXOS Store</strong> in the main navigation sidebar.
                  </span>
                </div>

                <div className="p-3.5 rounded-xl border border-white/10 bg-white/[0.02] flex items-center gap-3 text-xs">
                  <span className="font-mono font-bold text-xs px-2.5 py-1 rounded bg-white/10 text-[#5ed29c]">
                    STEP 03
                  </span>
                  <span className="text-white/85">
                    Search for <strong className="text-[#5ed29c]">PeDitX-Ai</strong> and click <strong>Install</strong> to activate the AI service.
                  </span>
                </div>
              </div>

              {/* Note on Router Integration */}
              <div className="p-3 rounded-xl border border-white/5 bg-white/[0.02] flex items-center gap-2.5 text-xs text-white/60">
                <Shield className="w-4 h-4 text-[#5ed29c] shrink-0" />
                <span>
                  The service will automatically hook into UCI and router daemon processes upon store installation.
                </span>
              </div>
            </div>
          ) : (
            /* GNOME Linux Section: Installed via https://peditx.ir/ai/linux-install.sh */
            <div className="space-y-4">
              <div className="p-4 rounded-xl border border-[#5ed29c]/30 bg-[#5ed29c]/5">
                <div className="flex items-start gap-3">
                  <Terminal className="w-5 h-5 text-[#5ed29c] shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-['Inter'] font-bold text-sm text-white mb-1">
                      Automated GNOME Linux Installer
                    </h3>
                    <p className="font-['Inter'] text-xs text-white/70 leading-relaxed">
                      Run the official setup script in your terminal to install and configure PeDitX-Ai on GNOME Linux (Ubuntu, Debian, Fedora, Arch):
                    </p>
                  </div>
                </div>
              </div>

              {/* Method Toggle: curl vs wget */}
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-white/60">Download utility:</span>
                  <button
                    type="button"
                    onClick={() => setCopyMethod('curl')}
                    className={`px-3 py-1 rounded-lg font-mono font-medium transition-colors cursor-pointer ${
                      copyMethod === 'curl' ? 'bg-[#5ed29c] text-[#070b0a]' : 'bg-white/10 text-white/70 hover:text-white'
                    }`}
                  >
                    curl
                  </button>
                  <button
                    type="button"
                    onClick={() => setCopyMethod('wget')}
                    className={`px-3 py-1 rounded-lg font-mono font-medium transition-colors cursor-pointer ${
                      copyMethod === 'wget' ? 'bg-[#5ed29c] text-[#070b0a]' : 'bg-white/10 text-white/70 hover:text-white'
                    }`}
                  >
                    wget
                  </button>
                </div>
                <span className="text-white/40 font-mono text-[11px]">Requires root / sudo</span>
              </div>

              {/* Live Command Box with Copy */}
              <div className="bg-[#060a08] border border-white/15 rounded-xl p-3.5 font-mono text-xs text-[#5ed29c] flex items-center justify-between gap-3 shadow-inner">
                <div className="flex items-center gap-2 overflow-x-auto py-1 pr-2">
                  <span className="text-white/30 select-none">$</span>
                  <code className="text-white whitespace-nowrap">{currentGnomeCommand}</code>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy(currentGnomeCommand)}
                  className="shrink-0 rounded-lg bg-white/10 hover:bg-[#5ed29c] hover:text-[#070b0a] text-white px-3 py-1.5 flex items-center gap-1.5 transition-all text-xs font-bold cursor-pointer"
                  title="Copy command to clipboard"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#5ed29c]" />
                      <span className="text-[#5ed29c]">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Command</span>
                    </>
                  )}
                </button>
              </div>

              {/* Direct link to the script */}
              <div className="flex items-center justify-between text-xs text-white/50 pt-1">
                <span>Script endpoint:</span>
                <a
                  href="https://peditx.ir/ai/linux-install.sh"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-mono text-[#5ed29c] hover:underline flex items-center gap-1"
                >
                  <span>https://peditx.ir/ai/linux-install.sh</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          )}

          {/* Footer links */}
          <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
            <a
              href="https://peditxos.ir"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-white/70 hover:text-white transition-colors"
            >
              <Globe className="w-3.5 h-3.5 text-[#5ed29c]" />
              <span>PeDitXOS Firmware Hub</span>
            </a>

            <a
              href="https://github.com/peditx"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-white/70 hover:text-white transition-colors"
            >
              <span>GitHub Repository</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
