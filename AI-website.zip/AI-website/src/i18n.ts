/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Bilingual string table (English / Persian).
 * Every user-visible string lives here so the language toggle can swap the
 * whole interface in one place.
 */

export type Lang = 'en' | 'fa';
export type L = Record<Lang, string>;

export const UI = {
  /* Header / navigation */
  navProjects: { en: 'Projects', fa: 'پروژه‌ها' },
  navPeDitXOS: { en: 'PeDitXOS', fa: 'PeDitXOS' },
  navAbout: { en: 'About', fa: 'درباره ما' },
  navGitHub: { en: 'GitHub', fa: 'GitHub' },
  installGuide: { en: 'Install Guide', fa: 'راهنمای نصب' },

  /* Preloader */
  skipIntro: { en: 'Skip Intro', fa: 'رد شدن' },

  /* Mobile menu */
  mobileTagline: { en: 'Control Your OS With AI', fa: 'سیستم‌عامل خود را با هوش مصنوعی کنترل کنید' },
  openDeployGuide: { en: 'Open Deployment Guide', fa: 'باز کردن راهنمای استقرار' },
  readyFooter: { en: 'PeDitXOS & GNOME Linux Ready · 2026', fa: 'PeDitXOS و GNOME Linux آماده‌اند · 2026' },

  /* Portal / cursor */
  next: { en: 'Next:', fa: 'بعدی:' },
  travel: { en: 'Travel', fa: 'سفر' },

  /* Language toggle — the button is always labelled with its TARGET language */
  langToggleText: { en: 'FA', fa: 'EN' },
  langToggleAria: { en: 'تغییر زبان به فارسی', fa: 'Switch language to English' },

  /* Screen-reader labels */
  ariaPortal: { en: 'PeDitX-Ai Operating System Portal', fa: 'پورتال سیستم‌عامل PeDitX-Ai' },
  ariaLoading: { en: 'Loading PeDitX-Ai', fa: 'در حال بارگذاری PeDitX-Ai' },
  ariaInstallGuide: { en: 'Open PeDitX-Ai Installation Guide', fa: 'باز کردن راهنمای نصب PeDitX-Ai' },
  ariaMobileNav: { en: 'Toggle mobile navigation', fa: 'باز و بسته کردن منوی موبایل' },
  ariaEnvironments: { en: 'System Environments', fa: 'محیط‌های سیستم' },
  ariaNextDestination: { en: 'Next destination', fa: 'مقصد بعدی' },
  altMercury: { en: 'Mercury', fa: 'عطارد' },

  travelTo: (name: string): L => ({
    en: `Travel to ${name}`,
    fa: `سفر به ${name}`,
  }),

  /* ------------------------------------------------------------------ */
  /* Installation guide modal                                            */
  /* ------------------------------------------------------------------ */
  modalBadge: { en: 'PeDitX-Ai · Installation Guide', fa: 'PeDitX-Ai · راهنمای نصب' },
  modalClose: { en: 'Close dialog', fa: 'بستن پنجره' },
  selectEnvironment: { en: 'Select Your Target Environment', fa: 'محیط مقصد خود را انتخاب کنید' },

  tabOpenwrtTitle: { en: 'PeDitXOS (OpenWrt)', fa: 'PeDitXOS (OpenWrt)' },
  tabOpenwrtSub: { en: 'PeDitXOS Store', fa: 'فروشگاه PeDitXOS' },
  tabGnomeTitle: { en: 'GNOME Linux', fa: 'GNOME Linux' },
  tabGnomeSub: { en: 'Automated Install Script', fa: 'اسکریپت نصب خودکار' },

  /* PeDitXOS branch */
  oxTitle: { en: 'Direct Installation via PeDitXOS Store', fa: 'نصب مستقیم از فروشگاه PeDitXOS' },
  oxBody: {
    en: 'On PeDitXOS, installation is exclusively handled through the built-in PeDitXOS Store inside your router’s administration web panel. No manual terminal commands or external packages are required.',
    fa: 'در PeDitXOS، نصب به‌صورت انحصاری از طریق فروشگاه داخلی PeDitXOS در پنل مدیریت روتر انجام می‌شود. نیازی به هیچ دستور دستی ترمینال یا بسته خارجی نیست.',
  },
  howToInstall: { en: 'How to Install on PeDitXOS:', fa: 'نصب در PeDitXOS:' },
  step01: { en: 'STEP 01', fa: 'گام ۰۱' },
  step02: { en: 'STEP 02', fa: 'گام ۰۲' },
  step03: { en: 'STEP 03', fa: 'گام ۰۳' },
  step1Pre: {
    en: 'Open your router’s web panel by navigating to ',
    fa: 'پنل وب روتر خود را در مرورگر باز کنید و به آدرس ',
  },
  step1Post: {
    en: ' (or your gateway address) in your browser.',
    fa: ' (یا آدرس دروازه پیش‌فرض) بروید.',
  },
  step2Pre: { en: 'Navigate to ', fa: 'در نوار کناری اصلی به ' },
  step2Store: { en: 'PeDitXOS Store', fa: 'PeDitXOS Store' },
  step2Post: { en: ' in the main navigation sidebar.', fa: ' بروید.' },
  /* step03 is rendered from five ordered parts: [pre, a, mid, b, post] */
  step3: {
    en: ['Search for ', 'PeDitX-Ai', ' and click ', 'Install', ' to activate the AI service.'],
    fa: ['عبارت ', 'PeDitX-Ai', ' را جستجو کنید و روی ', 'نصب', ' بزنید تا سرویس فعال شود.'],
  },
  shieldNote: {
    en: 'The service will automatically hook into UCI and router daemon processes upon store installation.',
    fa: 'سرویس پس از نصب از فروشگاه، به‌صورت خودکار به UCI و پروسه‌های دیمون روتر متصل می‌شود.',
  },

  /* GNOME Linux branch */
  gnTitle: { en: 'Automated GNOME Linux Installer', fa: 'نصب‌کننده خودکار GNOME Linux' },
  gnBody: {
    en: 'Run the official setup script in your terminal to install and configure PeDitX-Ai on GNOME Linux (Ubuntu, Debian, Fedora, Arch):',
    fa: 'برای نصب و پیکربندی PeDitX-Ai روی GNOME Linux (Ubuntu، Debian، Fedora، Arch) اسکریپت رسمی را در ترمینال اجرا کنید:',
  },
  downloadUtility: { en: 'Download utility:', fa: 'ابزار دانلود:' },
  requiresRoot: { en: 'Requires root / sudo', fa: 'نیازمند دسترسی root' },
  copyCommand: { en: 'Copy Command', fa: 'کپی دستور' },
  copied: { en: 'Copied!', fa: 'کپی شد!' },
  copyCommandTitle: { en: 'Copy command to clipboard', fa: 'کپی دستور در کلیپ‌بورد' },
  scriptEndpoint: { en: 'Script endpoint:', fa: 'آدرس اسکریپت:' },
  firmwareHub: { en: 'PeDitXOS Firmware Hub', fa: 'مرکز فریمور PeDitXOS' },
  gitHubRepository: { en: 'GitHub Repository', fa: 'مخزن گیت‌هاب' },
} as const;

/** Install commands stay byte-for-byte identical in both languages. */
export const COMMANDS = {
  curl: 'curl -fsSL https://peditx.ir/ai/linux-install.sh | sudo bash',
  wget: 'wget -qO- https://peditx.ir/ai/linux-install.sh | sudo bash',
  scriptUrl: 'https://peditx.ir/ai/linux-install.sh',
} as const;
