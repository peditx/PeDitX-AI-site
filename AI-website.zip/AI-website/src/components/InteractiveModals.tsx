import React, { useState } from 'react';
import { X, Check, Copy, Terminal, ExternalLink, Store, CheckCircle2, ChevronRight, Globe, Shield } from 'lucide-react';
import { UI, COMMANDS, type Lang } from '../i18n.ts';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Lang;
  type?: 'get_started' | 'projects' | 'blog' | 'about' | 'resume' | 'liquid_card' | null;
}

export const InteractiveModals: React.FC<ModalProps> = ({ isOpen, onClose, lang }) => {
  const [platform, setPlatform] = useState<'openwrt' | 'gnome'>('openwrt');
  const [copied, setCopied] = useState(false);
  const [copyMethod, setCopyMethod] = useState<'curl' | 'wget'>('curl');

  if (!isOpen) return null;

  const currentGnomeCommand = copyMethod === 'curl' ? COMMANDS.curl : COMMANDS.wget;
  const step3 = UI.step3[lang];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-[#070b0a]/85 backdrop-blur-md transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Modal Card */}
      <div
        className="relative z-10 w-full max-w-2xl bg-[#0c1311] border border-white/10 rounded-2xl shadow-[0_24px_64px_rgba(0,0,0,0.8),0_0_40px_rgba(94,210,156,0.12)] overflow-hidden text-white my-8 max-h-[92vh] flex flex-col"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-[#090f0d]">
          <div className="flex items-center gap-2.5">
            <span className="w-2 h-2 rounded-full bg-[#5ed29c] animate-pulse" />
            <span className="font-mono text-xs text-[#5ed29c] font-semibold tracking-wider uppercase">
              {UI.modalBadge[lang]}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/60 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label={UI.modalClose[lang]}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-7 overflow-y-auto space-y-6">
          {/* Target Environment Tabs */}
          <div>
            <label className="block text-xs font-['Inter'] font-semibold uppercase tracking-wider text-white/70 mb-2.5">
              {UI.selectEnvironment[lang]}
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* PeDitXOS Tab */}
              <button
                type="button"
                onClick={() => setPlatform('openwrt')}
                className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                  platform === 'openwrt'
                    ? 'border-[#5ed29c] bg-[#5ed29c]/10 text-white shadow-[0_0_16px_rgba(94,210,156,0.15)]'
                    : 'border-white/10 bg-white/[0.02] text-white/60 hover:border-white/20 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${platform === 'openwrt' ? 'bg-[#5ed29c] text-[#070b0a]' : 'bg-white/10 text-white'}`}>
                    <Store className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-['Inter'] font-bold text-sm">{UI.tabOpenwrtTitle[lang]}</div>
                    <div className="font-mono text-[11px] text-[#5ed29c]">{UI.tabOpenwrtSub[lang]}</div>
                  </div>
                </div>
                {platform === 'openwrt' && <CheckCircle2 className="w-4 h-4 text-[#5ed29c]" />}
              </button>

              {/* GNOME Linux Tab */}
              <button
                type="button"
                onClick={() => setPlatform('gnome')}
                className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                  platform === 'gnome'
                    ? 'border-[#5ed29c] bg-[#5ed29c]/10 text-white shadow-[0_0_16px_rgba(94,210,156,0.15)]'
                    : 'border-white/10 bg-white/[0.02] text-white/60 hover:border-white/20 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${platform === 'gnome' ? 'bg-[#5ed29c] text-[#070b0a]' : 'bg-white/10 text-white'}`}>
                    <Terminal className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-['Inter'] font-bold text-sm">{UI.tabGnomeTitle[lang]}</div>
                    <div className="font-mono text-[11px] text-[#5ed29c]">{UI.tabGnomeSub[lang]}</div>
                  </div>
                </div>
                {platform === 'gnome' && <CheckCircle2 className="w-4 h-4 text-[#5ed29c]" />}
              </button>
            </div>
          </div>

          {/* Platform Specific Installation Details */}
          {platform === 'openwrt' ? (
            /* PeDitXOS Section: Installed strictly through the internal PeDitXOS Store GUI */
            <div className="space-y-4">
              <div className="p-4 rounded-xl border border-[#5ed29c]/30 bg-[#5ed29c]/5">
                <div className="flex items-start gap-3">
                  <Store className="w-5 h-5 text-[#5ed29c] shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-['Inter'] font-bold text-sm text-white mb-1">
                      {UI.oxTitle[lang]}
                    </h3>
                    <p className="font-['Inter'] text-xs text-white/70 leading-relaxed">
                      {UI.oxBody[lang]}
                    </p>
                  </div>
                </div>
              </div>

              {/* Step by Step Visual Guide */}
              <div className="space-y-2.5">
                <span className="block text-xs font-['Inter'] font-semibold uppercase tracking-wider text-white/70">
                  {UI.howToInstall[lang]}
                </span>

                <div className="p-3.5 rounded-xl border border-white/10 bg-white/[0.02] flex items-center gap-3 text-xs">
                  <span className="font-mono font-bold text-xs px-2.5 py-1 rounded bg-white/10 text-[#5ed29c]">
                    {UI.step01[lang]}
                  </span>
                  <span className="text-white/85">
                    {UI.step1Pre[lang]}
                    <code className="font-mono text-[#5ed29c] bg-white/5 px-1.5 py-0.5 rounded ltr-latin">192.168.1.1</code>
                    {UI.step1Post[lang]}
                  </span>
                </div>

                <div className="p-3.5 rounded-xl border border-white/10 bg-white/[0.02] flex items-center gap-3 text-xs">
                  <span className="font-mono font-bold text-xs px-2.5 py-1 rounded bg-white/10 text-[#5ed29c]">
                    {UI.step02[lang]}
                  </span>
                  <span className="text-white/85">
                    {UI.step2Pre[lang]}
                    <strong>{UI.step2Store[lang]}</strong>
                    {UI.step2Post[lang]}
                  </span>
                </div>

                <div className="p-3.5 rounded-xl border border-white/10 bg-white/[0.02] flex items-center gap-3 text-xs">
                  <span className="font-mono font-bold text-xs px-2.5 py-1 rounded bg-white/10 text-[#5ed29c]">
                    {UI.step03[lang]}
                  </span>
                  <span className="text-white/85">
                    {step3[0]}
                    <strong className="text-[#5ed29c]">{step3[1]}</strong>
                    {step3[2]}
                    <strong>{step3[3]}</strong>
                    {step3[4]}
                  </span>
                </div>
              </div>

              {/* Note on Router Integration */}
              <div className="p-3 rounded-xl border border-white/5 bg-white/[0.02] flex items-center gap-2.5 text-xs text-white/60">
                <Shield className="w-4 h-4 text-[#5ed29c] shrink-0" />
                <span>
                  {UI.shieldNote[lang]}
                </span>
              </div>
            </div>
          ) : (
            /* GNOME Linux Section: Installed via https://peditx.ir/ai/linux-install.sh */
            <div className="space-y-4">
              <div className="p-4 rounded-xl border border-[#5ed29c]/30 bg-[#5ed29c]/5">
                <div className="flex items-start gap-3">
                  <Terminal className="w-5 h-5 text-[#5ed29c] shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-['Inter'] font-bold text-sm text-white mb-1">
                      {UI.gnTitle[lang]}
                    </h3>
                    <p className="font-['Inter'] text-xs text-white/70 leading-relaxed">
                      {UI.gnBody[lang]}
                    </p>
                  </div>
                </div>
              </div>

              {/* Method Toggle: curl vs wget */}
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-white/60">{UI.downloadUtility[lang]}</span>
                  <button
                    type="button"
                    onClick={() => setCopyMethod('curl')}
                    className={`px-3 py-1 rounded-lg font-mono font-medium transition-colors cursor-pointer ${
                      copyMethod === 'curl' ? 'bg-[#5ed29c] text-[#070b0a]' : 'bg-white/10 text-white/70 hover:text-white'
                    }`}
                  >
                    curl
                  </button>
                  <button
                    type="button"
                    onClick={() => setCopyMethod('wget')}
                    className={`px-3 py-1 rounded-lg font-mono font-medium transition-colors cursor-pointer ${
                      copyMethod === 'wget' ? 'bg-[#5ed29c] text-[#070b0a]' : 'bg-white/10 text-white/70 hover:text-white'
                    }`}
                  >
                    wget
                  </button>
                </div>
                <span className="text-white/40 font-mono text-[11px]">{UI.requiresRoot[lang]}</span>
              </div>

              {/* Live Command Box with Copy */}
              <div className="bg-[#060a08] border border-white/15 rounded-xl p-3.5 font-mono text-xs text-[#5ed29c] flex items-center justify-between gap-3 shadow-inner">
                <div className="flex items-center gap-2 overflow-x-auto py-1 pr-2">
                  <span className="text-white/30 select-none">$</span>
                  <code className="text-white whitespace-nowrap ltr-latin">{currentGnomeCommand}</code>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy(currentGnomeCommand)}
                  className="shrink-0 rounded-lg bg-white/10 hover:bg-[#5ed29c] hover:text-[#070b0a] text-white px-3 py-1.5 flex items-center gap-1.5 transition-all text-xs font-bold cursor-pointer"
                  title={UI.copyCommandTitle[lang]}
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#5ed29c]" />
                      <span className="text-[#5ed29c]">{UI.copied[lang]}</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>{UI.copyCommand[lang]}</span>
                    </>
                  )}
                </button>
              </div>

              {/* Direct link to the script */}
              <div className="flex items-center justify-between text-xs text-white/50 pt-1">
                <span>{UI.scriptEndpoint[lang]}</span>
                <a
                  href={COMMANDS.scriptUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-mono text-[#5ed29c] hover:underline flex items-center gap-1 ltr-latin"
                >
                  <span>{COMMANDS.scriptUrl}</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          )}

          {/* Footer links */}
          <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
            <a
              href="https://peditxos.ir"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-white/70 hover:text-white transition-colors"
            >
              <Globe className="w-3.5 h-3.5 text-[#5ed29c]" />
              <span>{UI.firmwareHub[lang]}</span>
            </a>

            <a
              href="https://github.com/peditx"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-white/70 hover:text-white transition-colors"
            >
              <span>{UI.gitHubRepository[lang]}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
