/**
 * Horizontal text-scramble used when the interface swaps language.
 *
 * Every visible text leaf decodes glyph-by-glyph into the new language: the
 * unresolved positions flicker through random characters of the target script
 * while the resolved ones lock in left→right (right→left for Persian), with a
 * small stagger based on the element's horizontal position — so the whole page
 * appears to translate as a single wave sweeping across the screen.
 *
 * Deliberately DOM-level (no React involvement): one pass over the text leaves
 * is shorter than threading a wrapper component through ~50 call sites, and
 * React only overwrites a node when its own text actually changes.
 */

const LATIN = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
const PERSIAN = '۰۱۲۳۴۵۶۷۸۹ابتثجحخدذرزژسشصضطظعغفقکگلمنوهی';
const FA_RE = /[؀-ۿ]/;
const SPACE_RE = /\s/;

/** Max horizontal stagger across the viewport, in ms. */
const SWEEP_MS = 260;
/** Decode time per element, in ms. */
const DECODE_MS = 640;

interface Node {
  el: HTMLElement;
  text: string;
  pool: string;
  rtl: boolean;
  start: number;
}

let runId = 0;

export function runScramble(): void {
  const myRun = ++runId;
  const nodes: Node[] = [];

  document.querySelectorAll<HTMLElement>('body *').forEach((el) => {
    // Only leaves — anything with element children keeps its structure.
    if (el.children.length > 0) return;
    const text = el.textContent ?? '';
    if (!text.trim()) return;
    const rect = el.getBoundingClientRect();
    if (!rect.width && !rect.height) return;

    const rtl = FA_RE.test(text);
    const travel = (rtl ? window.innerWidth - rect.right : rect.left) / Math.max(window.innerWidth, 1);
    nodes.push({
      el,
      text,
      pool: rtl ? PERSIAN : LATIN,
      rtl,
      start: travel * SWEEP_MS,
    });
  });

  if (nodes.length === 0) return;

  const t0 = performance.now();

  const frame = (now: number) => {
    if (myRun !== runId) return; // superseded by a newer toggle
    let running = false;

    for (const n of nodes) {
      const p = (now - t0 - n.start) / DECODE_MS;
      if (p <= 0) {
        running = true;
        continue;
      }
      if (p >= 1) {
        n.el.textContent = n.text;
        continue;
      }
      running = true;

      const len = n.text.length;
      const revealed = Math.floor(p * len);
      let out = '';
      for (let i = 0; i < len; i++) {
        const ch = n.text[i];
        const order = n.rtl ? len - 1 - i : i;
        // Whitespace stays put so the element never reflows mid-decode.
        if (SPACE_RE.test(ch) || order < revealed) out += ch;
        else out += n.pool[(Math.random() * n.pool.length) | 0];
      }
      n.el.textContent = out;
    }

    if (running) requestAnimationFrame(frame);
  };

  requestAnimationFrame(frame);
}
