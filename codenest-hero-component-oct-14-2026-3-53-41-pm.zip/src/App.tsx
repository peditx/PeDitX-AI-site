/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { InteractiveModals } from './components/InteractiveModals.tsx';
import { usePWAInstall } from './hooks/usePWAInstall.ts';
import {
  Download,
  Menu,
  X,
  ArrowUpRight,
  ChevronRight,
} from 'lucide-react';

const BASE = 'https://d2ol7oe51mr4n9.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P';
const MARS_BG = `${BASE}/3c83091e-4046-4fd6-adbb-2edb728be79a.mp4`;
const TO_EARTH = `${BASE}/fc3ded42-e845-41f3-a830-5cab512d79cd.mp4`;
const TO_VENUS = `${BASE}/b30f64d9-1637-477a-83df-d0fc6461a422.mp4`;
const TO_MARS = `${BASE}/5fc5651c-3b5d-4171-b507-87f7e635d1b4.mp4`;
const MERCURY = `${BASE}/d6fb8b6b-c15e-4aaa-9cf7-45bbb5e33372.jpg`;

// High-performance Universal H.264 video streams (Zero-freeze across all browsers/platforms)
// Both PeDitXOS, Linux GNOME, and AI Core use matched high-definition cinematic celestial planet animations
const MARS_BG_LOCAL = '/videos/to_mars.mp4';
const TO_EARTH_LOCAL = '/videos/to_earth.mp4';
const TO_VENUS_LOCAL = '/videos/to_venus.mp4';
const TO_MARS_LOCAL = '/videos/to_mars.mp4';

// User requested exact logo URL
const PEDITX_LOGO = 'https://firmware.peditxos.ir/fav/apple-touch-icon.png';

const environmentList = [
  'PeDitXOS',
  'Linux GNOME',
  'AI Core',
  'OpenWrt',
  'WireGuard',
  'eBPF Mesh',
  'Router UCI',
  'Docker Edge',
];

interface NodeState {
  id: 'mars' | 'earth' | 'venus';
  name: string;
  tagline: string;
  next: string;
  number: string;
  portal?: string;
  image?: string;
  background: string;
  gradientColors: [string, string, string];
  facts: [string, string][];
}

const nodeStates: Record<'mars' | 'earth' | 'venus', NodeState> = {
  mars: {
    id: 'mars',
    name: 'PEDITXOS',
    tagline: 'Autonomous AI Router Intelligence & eBPF Telemetry',
    next: 'Linux GNOME',
    number: '[02]',
    portal: TO_EARTH_LOCAL,
    background: 'mars-background',
    gradientColors: ['#2e120d', '#180a07', '#090807'],
    facts: [
      ['System:', 'PeDitXOS (OpenWrt 23.05 Core)'],
      ['Store:', 'Installed exclusively via PeDitXOS Store'],
      ['Telemetry:', 'Real-time eBPF & UCI daemon automation'],
      ['Kernel:', 'Hardened router kernel with WireGuard mesh'],
    ],
  },
  earth: {
    id: 'earth',
    name: 'LINUX GNOME',
    tagline: 'Native Desktop & Enterprise Linux Terminal Automation',
    next: 'AI Core',
    number: '[03]',
    portal: TO_VENUS_LOCAL,
    background: 'earth-background',
    gradientColors: ['#122a36', '#09151c', '#090807'],
    facts: [
      ['System:', 'GNOME Desktop & Enterprise Linux'],
      ['Installer:', 'curl -fsSL https://peditx.ir/ai/linux-install.sh | sudo bash'],
      ['IPC Bus:', 'D-Bus systemd units & terminal orchestration'],
      ['Distros:', 'Ubuntu, Debian, Fedora & Arch Linux'],
    ],
  },
  venus: {
    id: 'venus',
    name: 'AI CORE',
    tagline: 'Unified Neural Operating System Mesh & Sandbox',
    next: 'PeDitXOS',
    number: '[01]',
    portal: TO_MARS_LOCAL,
    image: MERCURY,
    background: 'venus-background',
    gradientColors: ['#281e0e', '#140e06', '#090807'],
    facts: [
      ['Engine:', 'Autonomous natural-language OS directives'],
      ['Network:', 'Automated QoS, firewall & traffic routing'],
      ['Security:', 'Zero-trust sandbox & isolated root execution'],
      ['Interface:', 'Web dashboard at :9090 & local CLI agent'],
    ],
  },
};

export default function App() {
  const [currentNode, setCurrentNode] = useState<'mars' | 'earth' | 'venus'>('mars');
  const [isInstallOpen, setIsInstallOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showIOSModal, setShowIOSModal] = useState(false);

  // Preloader State
  const [isIntroReady, setIsIntroReady] = useState(false);
  const [preloaderCount, setPreloaderCount] = useState(0);
  const [logoDocked, setLogoDocked] = useState(false);
  const [logoSettled, setLogoSettled] = useState(false);
  const [preloaderLeaving, setPreloaderLeaving] = useState(false);
  const [preloaderDone, setPreloaderDone] = useState(false);

  // PWA Hook
  const { isInstallable, isInstalled, isIOS, install: installPWA } = usePWAInstall();

  // Refs
  const experienceRef = useRef<HTMLDivElement | null>(null);
  const portalCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const sceneCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const portalBtnRef = useRef<HTMLButtonElement | null>(null);
  const portalVideoRef = useRef<HTMLVideoElement | null>(null);
  const portalImgRef = useRef<HTMLImageElement | null>(null);
  const transitionVideoRef = useRef<HTMLVideoElement | null>(null);
  const preloaderVideoRef = useRef<HTMLVideoElement | null>(null);

  const marsBgRef = useRef<HTMLVideoElement | null>(null);
  const earthBgRef = useRef<HTMLVideoElement | null>(null);
  const venusBgRef = useRef<HTMLVideoElement | null>(null);

  const cursorRef = useRef<HTMLDivElement | null>(null);
  const cursorOrbitRef = useRef<HTMLSpanElement | null>(null);

  // Physics animation state
  const physics = useRef({
    busy: false,
    expansion: 0,
    maskScale: 1,
    canvasOpacity: 1,
    transitionActive: false,
    hasFrozenScene: false,
    rotX: 0,
    rotY: 0,
    targetX: 0,
    targetY: 0,
    cursorX: -100,
    cursorY: -100,
    orbitX: -100,
    orbitY: -100,
    cursorVisible: false,
    cursorEnter: false,
    isTouch: false,
    particlesPhase: 0,
  });

  const cubicEase = (t: number) =>
    t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

  const animateValue = (setter: (v: number) => void, duration: number): Promise<void> => {
    return new Promise((resolve) => {
      const start = performance.now();
      const frame = (now: number) => {
        const elapsed = now - start;
        const progress = Math.min(1, elapsed / duration);
        setter(cubicEase(progress));
        if (progress < 1) {
          requestAnimationFrame(frame);
        } else {
          resolve();
        }
      };
      requestAnimationFrame(frame);
    });
  };

  const drawShade = (ctx: CanvasRenderingContext2D) => {
    const w = window.innerWidth;
    const h = window.innerHeight;
    const grad = ctx.createLinearGradient(0, h * 0.45, 0, h);
    grad.addColorStop(0, 'rgba(0,0,0,0)');
    grad.addColorStop(1, 'rgba(9,8,7,0.88)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, h * 0.45, w, h * 0.55);
  };

  // Draws glowing animated fallback texture inside portal if video is buffering/delayed
  const drawPortalFallback = (ctx: CanvasRenderingContext2D, state: NodeState, phase: number) => {
    const w = window.innerWidth;
    const h = window.innerHeight;
    const grad = ctx.createRadialGradient(w / 2, h / 2, 20, w / 2, h / 2, Math.max(w, h) * 0.55);
    grad.addColorStop(0, state.gradientColors[0]);
    grad.addColorStop(0.5, state.gradientColors[1]);
    grad.addColorStop(1, state.gradientColors[2]);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    // Subtle animated cyber grid & orbital rings
    ctx.save();
    ctx.translate(w / 2, h / 2);
    ctx.rotate(phase * 0.0004);

    ctx.strokeStyle = 'rgba(94, 210, 156, 0.15)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(0, 0, 110, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.beginPath();
    ctx.arc(0, 0, 180, 0, Math.PI * 2);
    ctx.stroke();

    // Orbital dots
    for (let i = 0; i < 6; i++) {
      const angle = (Math.PI * 2 * i) / 6 + phase * 0.0008;
      const x = Math.cos(angle) * 110;
      const y = Math.sin(angle) * 110;
      ctx.fillStyle = 'rgba(94, 210, 156, 0.5)';
      ctx.beginPath();
      ctx.arc(x, y, 3, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  };

  const drawCover = (ctx: CanvasRenderingContext2D, media: HTMLVideoElement | HTMLImageElement) => {
    const isVideo = media instanceof HTMLVideoElement;
    if (isVideo && media.readyState < 2) {
      return false;
    }
    const mw =
      (media as HTMLVideoElement).videoWidth ||
      (media as HTMLImageElement).naturalWidth ||
      0;
    const mh =
      (media as HTMLVideoElement).videoHeight ||
      (media as HTMLImageElement).naturalHeight ||
      0;
    if (!mw || !mh) return false;

    const scale = Math.max(window.innerWidth / mw, window.innerHeight / mh);
    const w = mw * scale;
    const h = mh * scale;
    try {
      ctx.drawImage(media, (window.innerWidth - w) / 2, (window.innerHeight - h) / 2, w, h);
      return true;
    } catch {
      return false;
    }
  };

  // 3D Canvas Rendering Loop
  useEffect(() => {
    let animId: number;

    const resizeCanvas = () => {
      const d = Math.min(window.devicePixelRatio || 1, 2);
      const w = window.innerWidth;
      const h = window.innerHeight;

      [portalCanvasRef.current, sceneCanvasRef.current].forEach((canvas) => {
        if (!canvas) return;
        canvas.width = Math.round(w * d);
        canvas.height = Math.round(h * d);
        canvas.style.width = `${w}px`;
        canvas.style.height = `${h}px`;
        const ctx = canvas.getContext('2d');
        if (ctx) ctx.setTransform(d, 0, 0, d, 0, 0);
      });
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    const renderLoop = (timestamp: number) => {
      animId = requestAnimationFrame(renderLoop);

      const canvas = portalCanvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const p = physics.current;
      const d = Math.min(window.devicePixelRatio || 1, 2);
      p.particlesPhase = timestamp;

      // Smooth pointer damping
      p.rotX += (p.targetX - p.rotX) * 0.085;
      p.rotY += (p.targetY - p.rotY) * 0.085;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Transition frozen frame drawing - strictly only during active travel transition
      if (p.hasFrozenScene && sceneCanvasRef.current) {
        ctx.save();
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.drawImage(sceneCanvasRef.current, 0, 0, canvas.width, canvas.height);
        ctx.restore();
        drawShade(ctx);
      }

      const portalBtn = portalBtnRef.current;
      if (!portalBtn) return;
      const rect = portalBtn.getBoundingClientRect();
      const rectCx = rect.left + rect.width / 2;
      const rectCy = rect.top + rect.height / 2;

      const e = p.expansion;
      const cx = rectCx + (window.innerWidth / 2 - rectCx) * e;
      const cy = rectCy + (window.innerHeight / 2 - rectCy) * e;
      const baseW = rect.width + (window.innerWidth - rect.width) * e;
      const baseH = rect.height + (window.innerHeight - rect.height) * e;
      const scale = e ? 1 : p.maskScale;
      const w = baseW * scale;
      const h = baseH * scale;

      const maxRadius = Math.min(w / 2, h / 2);
      const isMobile = window.innerWidth <= 820;
      const initialR = isMobile ? 54 : 80;
      const r = Math.min(maxRadius, initialR * (1 - e) * scale);
      const rx = p.rotX * (1 - e);
      const ry = p.rotY * (1 - e);

      if (w > 1 && h > 1) {
        const arcSteps = 10;
        const cornerArcs = [
          { cx: w / 2 - r, cy: -h / 2 + r, start: -Math.PI / 2, end: 0 },
          { cx: w / 2 - r, cy: h / 2 - r, start: 0, end: Math.PI / 2 },
          { cx: -w / 2 + r, cy: h / 2 - r, start: 0.5 * Math.PI, end: Math.PI },
          { cx: -w / 2 + r, cy: -h / 2 + r, start: Math.PI, end: 1.5 * Math.PI },
        ];

        const points: [number, number][] = [];
        cornerArcs.forEach((arc) => {
          for (let i = 0; i <= arcSteps; i++) {
            const angle = arc.start + ((arc.end - arc.start) * i) / arcSteps;
            const px = arc.cx + Math.cos(angle) * r;
            const py = arc.cy + Math.sin(angle) * r;
            points.push([px, py]);
          }
        });

        // Perspective projection: focal = 850
        const ax = (rx * Math.PI) / 180;
        const ay = (ry * Math.PI) / 180;
        const cosAy = Math.cos(ay);
        const sinAy = Math.sin(ay);
        const cosAx = Math.cos(ax);
        const sinAx = Math.sin(ax);

        const projected = points.map(([x, y]) => {
          const xx = x * cosAy;
          const yy = y * cosAx;
          const z = x * sinAy - y * sinAx;
          const focalP = 850 / (850 + z);
          return [cx + xx * focalP, cy + yy * focalP];
        });

        ctx.save();
        ctx.globalAlpha = p.canvasOpacity;
        ctx.beginPath();
        projected.forEach(([px, py], idx) => {
          if (idx === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        });
        ctx.closePath();
        ctx.clip();

        // 1. Draw glowing background texture first
        drawPortalFallback(ctx, nodeStates[currentNode], p.particlesPhase);

        // 2. Sample live media over it with exact cover dimensions
        let activeMedia: HTMLVideoElement | HTMLImageElement | null = null;
        if (p.transitionActive) {
          activeMedia = transitionVideoRef.current || portalVideoRef.current;
        } else if (nodeStates[currentNode].image && portalImgRef.current) {
          activeMedia = portalImgRef.current;
        } else if (portalVideoRef.current) {
          activeMedia = portalVideoRef.current;
        }

        if (activeMedia) {
          drawCover(ctx, activeMedia);
        }

        if (p.transitionActive) {
          drawShade(ctx);
        }

        ctx.restore();
      }
    };

    animId = requestAnimationFrame(renderLoop);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resizeCanvas);
    };
  }, [currentNode]);

  // Touch & Pointer Physics
  useEffect(() => {
    let animId: number;

    const cursorLoop = () => {
      animId = requestAnimationFrame(cursorLoop);
      const p = physics.current;
      if (p.isTouch) return;

      p.orbitX += (p.cursorX - p.orbitX) * 0.22;
      p.orbitY += (p.cursorY - p.orbitY) * 0.22;

      if (cursorRef.current) {
        cursorRef.current.style.transform = `translate3d(${p.cursorX}px, ${p.cursorY}px, 0)`;
        if (p.cursorVisible) {
          cursorRef.current.classList.add('is-visible');
        } else {
          cursorRef.current.classList.remove('is-visible');
        }
        if (p.cursorEnter) {
          cursorRef.current.classList.add('is-enter');
        } else {
          cursorRef.current.classList.remove('is-enter');
        }
      }

      if (cursorOrbitRef.current) {
        cursorOrbitRef.current.style.transform = `translate3d(${p.orbitX - p.cursorX}px, ${
          p.orbitY - p.cursorY
        }px, 0)`;
      }
    };

    animId = requestAnimationFrame(cursorLoop);

    const onPointerMove = (e: PointerEvent) => {
      const p = physics.current;
      if (e.pointerType === 'touch') {
        p.isTouch = true;
        document.body.classList.add('touch-device');
      } else {
        p.isTouch = false;
        document.body.classList.remove('touch-device');
      }

      p.cursorVisible = true;
      p.cursorX = e.clientX;
      p.cursorY = e.clientY;

      if (!p.busy) {
        p.targetY = (e.clientX / window.innerWidth - 0.5) * 26;
        p.targetX = (e.clientY / window.innerHeight - 0.5) * -22;
      }
    };

    let touchStartX = 0;
    let touchStartY = 0;

    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
      }
    };

    const onTouchEnd = (e: TouchEvent) => {
      if (e.changedTouches.length > 0) {
        const diffX = touchStartX - e.changedTouches[0].clientX;
        const diffY = touchStartY - e.changedTouches[0].clientY;
        if (Math.abs(diffX) > 44 && Math.abs(diffX) > Math.abs(diffY)) {
          if (diffX > 0) {
            // Swiped left -> next slide
            setCurrentNode((curr) => (curr === 'mars' ? 'earth' : curr === 'earth' ? 'venus' : 'mars'));
          } else {
            // Swiped right -> prev slide
            setCurrentNode((curr) => (curr === 'venus' ? 'earth' : curr === 'earth' ? 'mars' : 'venus'));
          }
        }
      }
    };

    const onPointerLeave = () => {
      physics.current.cursorVisible = false;
    };

    document.addEventListener('pointermove', onPointerMove, { passive: true });
    document.addEventListener('touchstart', onTouchStart, { passive: true });
    document.addEventListener('touchend', onTouchEnd, { passive: true });
    document.addEventListener('pointerleave', onPointerLeave);

    return () => {
      cancelAnimationFrame(animId);
      document.removeEventListener('pointermove', onPointerMove);
      document.removeEventListener('touchstart', onTouchStart);
      document.removeEventListener('touchend', onTouchEnd);
      document.removeEventListener('pointerleave', onPointerLeave);
    };
  }, []);

  // Lock background video on the final frame when travel sequence completes
  // "bayad sare frame akhar fix beshe dge hey bar nagardim sare khouneye aval"
  const handleVideoEnded = (e: React.SyntheticEvent<HTMLVideoElement>) => {
    const vid = e.currentTarget;
    vid.pause();
    if (vid.duration && !isNaN(vid.duration)) {
      vid.currentTime = Math.max(0, vid.duration - 0.03);
    }
  };

  const handleTimeUpdate = (e: React.SyntheticEvent<HTMLVideoElement>) => {
    const vid = e.currentTarget;
    if (vid.duration && !isNaN(vid.duration) && vid.currentTime >= vid.duration - 0.05) {
      vid.pause();
      vid.currentTime = Math.max(0, vid.duration - 0.03);
    }
  };

  // Preloader Sequence: Smooth and quick
  useEffect(() => {
    let finished = false;
    let count = 0;

    const completeIntro = () => {
      if (finished) return;
      finished = true;
      setPreloaderCount(100);
      setPreloaderLeaving(true);
      setLogoDocked(true);

      // Stop preloader video
      if (preloaderVideoRef.current) {
        preloaderVideoRef.current.pause();
      }

      // Start Mars background video, playing smoothly to arrival and locking on the last frame
      if (marsBgRef.current) {
        marsBgRef.current.muted = true;
        marsBgRef.current.defaultMuted = true;
        marsBgRef.current.loop = false;
        marsBgRef.current.currentTime = 0;
        marsBgRef.current.play().catch(() => {});
      }

      // Keep portal preview icon strictly paused - only plays when user travels
      if (portalVideoRef.current) {
        portalVideoRef.current.pause();
        portalVideoRef.current.currentTime = 0;
      }

      setTimeout(() => {
        setIsIntroReady(true);
        setPreloaderDone(true);
      }, 450);

      setTimeout(() => {
        setLogoSettled(true);
      }, 1400);
    };

    const interval = setInterval(() => {
      count += Math.floor(Math.random() * 14) + 10;
      if (count >= 100) {
        count = 100;
        clearInterval(interval);
        completeIntro();
      }
      setPreloaderCount(count);
    }, 40);

    const video = preloaderVideoRef.current;
    if (video) {
      video.play().catch(() => {});
      video.addEventListener('ended', completeIntro, { once: true });
    }

    const timeout = setTimeout(completeIntro, 1600);

    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
    };
  }, []);

  // Sync background video switching and ensure playback settles and locks on final frame
  useEffect(() => {
    const bgMap: Record<string, HTMLVideoElement | null> = {
      mars: marsBgRef.current,
      earth: earthBgRef.current,
      venus: venusBgRef.current,
    };

    const currentBg = bgMap[currentNode];
    if (currentBg) {
      currentBg.muted = true;
      currentBg.defaultMuted = true;
      currentBg.loop = false;
      currentBg.classList.add('is-visible');

      const startPlay = () => {
        if (!currentBg) return;
        currentBg.muted = true;
        currentBg.defaultMuted = true;
        currentBg.loop = false;
        // If arrived or switching, play to end and hold last frame
        if (currentBg.ended || (currentBg.duration && currentBg.currentTime >= currentBg.duration - 0.1)) {
          currentBg.currentTime = 0;
        }
        currentBg.play().catch(() => {});
      };
      startPlay();
      currentBg.addEventListener('canplay', startPlay, { once: true });
    }

    Object.entries(bgMap).forEach(([key, vid]) => {
      if (!vid || key === currentNode) return;
      vid.classList.remove('is-visible');
      vid.pause();
    });

    // Portal icon preview: load next destination but keep PAUSED (no extra playback)
    const portalVid = portalVideoRef.current;
    if (portalVid && nodeStates[currentNode].portal) {
      portalVid.muted = true;
      portalVid.defaultMuted = true;
      const targetSrc = nodeStates[currentNode].portal!;
      if (portalVid.src !== targetSrc) {
        portalVid.src = targetSrc;
        portalVid.load();
      }
      portalVid.pause();
      portalVid.currentTime = 0;
    }
  }, [currentNode]);

  // Global user interaction listener to unblock browser autoplay restrictions only if initial play was blocked
  useEffect(() => {
    const unlockVideos = () => {
      const bgMap: Record<string, HTMLVideoElement | null> = {
        mars: marsBgRef.current,
        earth: earthBgRef.current,
        venus: venusBgRef.current,
      };
      const currentBg = bgMap[currentNode];
      // Only unlock if autoplay was blocked before the video reached its final destination frame
      if (
        currentBg &&
        currentBg.paused &&
        !currentBg.ended &&
        (!currentBg.duration || currentBg.currentTime < currentBg.duration - 0.1)
      ) {
        currentBg.muted = true;
        currentBg.defaultMuted = true;
        currentBg.loop = false;
        currentBg.play().catch(() => {});
      }
    };

    window.addEventListener('pointerdown', unlockVideos, { passive: true });
    window.addEventListener('touchstart', unlockVideos, { passive: true });
    window.addEventListener('click', unlockVideos, { passive: true });

    return () => {
      window.removeEventListener('pointerdown', unlockVideos);
      window.removeEventListener('touchstart', unlockVideos);
      window.removeEventListener('click', unlockVideos);
    };
  }, [currentNode]);

  // Seamless, glitch-free travel sequence with 1:1 pixel scaling
  const handleTravel = async () => {
    const p = physics.current;
    if (p.busy) return;
    p.busy = true;
    p.targetX = 0;
    p.targetY = 0;

    const nextNode = currentNode === 'mars' ? 'earth' : currentNode === 'earth' ? 'venus' : 'mars';
    const portalVid = portalVideoRef.current;
    const transitionVideo = transitionVideoRef.current;
    const expEl = experienceRef.current;

    try {
      if (expEl) {
        expEl.classList.add('is-transitioning');
      }

      // Smoothly expand portal from 0 to 1 over 750ms without reloading media
      p.canvasOpacity = 1;
      p.transitionActive = true;

      if (portalVid) {
        portalVid.currentTime = 0;
        portalVid.playbackRate = 1.35;
        portalVid.play().catch(() => {});
      }

      await animateValue((v) => {
        p.expansion = v;
      }, 750);

      // Freeze frame into scene-canvas using exact 1:1 physical pixel dimensions
      const sceneCanvas = sceneCanvasRef.current;
      const sampleVid = portalVid && portalVid.videoWidth ? portalVid : transitionVideo;
      if (sampleVid && sceneCanvas) {
        const sCtx = sceneCanvas.getContext('2d');
        if (sCtx) {
          sCtx.save();
          sCtx.setTransform(1, 0, 0, 1, 0, 0);
          sCtx.clearRect(0, 0, sceneCanvas.width, sceneCanvas.height);
          const mw = sampleVid.videoWidth || (sampleVid as unknown as HTMLImageElement).naturalWidth;
          const mh = sampleVid.videoHeight || (sampleVid as unknown as HTMLImageElement).naturalHeight;
          if (mw && mh) {
            const scale = Math.max(sceneCanvas.width / mw, sceneCanvas.height / mh);
            const w = mw * scale;
            const h = mh * scale;
            sCtx.drawImage(
              sampleVid,
              (sceneCanvas.width - w) / 2,
              (sceneCanvas.height - h) / 2,
              w,
              h
            );
          }
          sCtx.restore();
          p.hasFrozenScene = true;
        }
      }

      // Switch to next node state
      setCurrentNode(nextNode);

      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));

      // Release frozen frame immediately so destination background video plays dynamically
      p.hasFrozenScene = false;
      p.transitionActive = false;
      p.expansion = 0;
      p.maskScale = 0;

      if (expEl) {
        expEl.classList.remove('is-transitioning');
      }

      if (portalVid) {
        portalVid.playbackRate = 1.0;
      }

      // Smoothly scale up portal on the new planet
      await animateValue((v) => {
        p.maskScale = v;
      }, 700);

      p.busy = false;
    } catch {
      p.transitionActive = false;
      p.expansion = 0;
      p.maskScale = 1;
      p.canvasOpacity = 1;
      p.hasFrozenScene = false;
      if (expEl) {
        expEl.classList.remove('is-transitioning');
      }
      p.busy = false;
    }
  };

  const active = nodeStates[currentNode];

  return (
    <>
      <main
        ref={experienceRef}
        className={`experience ${isIntroReady ? 'intro-ready' : 'intro-pending'}`}
        data-planet={currentNode}
        aria-label="PeDitX-Ai Operating System Portal"
      >
        {/* Background Videos with CORS enabled */}
        <div className="backgrounds" aria-hidden="true">
          <video
            ref={(el) => {
              marsBgRef.current = el;
              if (el) {
                el.muted = true;
                el.defaultMuted = true;
                el.loop = false;
              }
            }}
            id="mars-background"
            className="background is-visible"
            src={MARS_BG_LOCAL}
            crossOrigin="anonymous"
            autoPlay
            muted
            playsInline
            preload="auto"
            onEnded={handleVideoEnded}
            onTimeUpdate={handleTimeUpdate}
            onError={(e) => {
              const vid = e.currentTarget;
              if (vid.src.includes('to_mars.mp4') || vid.src.includes('mars_bg.mp4')) {
                vid.src = TO_MARS;
                vid.load();
                vid.play().catch(() => {});
              }
            }}
          />
          <video
            ref={(el) => {
              earthBgRef.current = el;
              if (el) {
                el.muted = true;
                el.defaultMuted = true;
                el.loop = false;
              }
            }}
            id="earth-background"
            className="background"
            src={TO_EARTH_LOCAL}
            crossOrigin="anonymous"
            autoPlay
            muted
            playsInline
            preload="auto"
            onEnded={handleVideoEnded}
            onTimeUpdate={handleTimeUpdate}
            onError={(e) => {
              const vid = e.currentTarget;
              if (vid.src.includes('to_earth.mp4')) {
                vid.src = TO_EARTH;
                vid.load();
                vid.play().catch(() => {});
              }
            }}
          />
          <video
            ref={(el) => {
              venusBgRef.current = el;
              if (el) {
                el.muted = true;
                el.defaultMuted = true;
                el.loop = false;
              }
            }}
            id="venus-background"
            className="background"
            src={TO_VENUS_LOCAL}
            crossOrigin="anonymous"
            autoPlay
            muted
            playsInline
            preload="auto"
            onEnded={handleVideoEnded}
            onTimeUpdate={handleTimeUpdate}
            onError={(e) => {
              const vid = e.currentTarget;
              if (vid.src.includes('to_venus.mp4')) {
                vid.src = TO_VENUS;
                vid.load();
                vid.play().catch(() => {});
              }
            }}
          />
        </div>

        {/* Video Preloader */}
        {!preloaderDone && (
          <div
            className={`preloader ${preloaderLeaving ? 'opacity-0 pointer-events-none' : ''}`}
            id="preloader"
            aria-label="Loading PeDitX-Ai"
            onClick={() => {
              setPreloaderCount(100);
              setPreloaderLeaving(true);
              setLogoDocked(true);
              setIsIntroReady(true);
              setPreloaderDone(true);
              setLogoSettled(true);
            }}
          >
            <video
              ref={(el) => {
                preloaderVideoRef.current = el;
                if (el) {
                  el.muted = true;
                  el.defaultMuted = true;
                }
              }}
              id="preloader-video"
              src={TO_MARS_LOCAL}
              crossOrigin="anonymous"
              autoPlay
              muted
              playsInline
              preload="auto"
              onError={(e) => {
                const vid = e.currentTarget;
                if (vid.src.includes('to_mars.mp4')) {
                  vid.src = TO_MARS;
                  vid.load();
                  vid.play().catch(() => {});
                }
              }}
            />
            <div className="preloader-shade" />

            <button
              onClick={(e) => {
                e.stopPropagation();
                setPreloaderCount(100);
                setPreloaderLeaving(true);
                setLogoDocked(true);
                setIsIntroReady(true);
                setPreloaderDone(true);
                setLogoSettled(true);
              }}
              className="skip-preloader-btn"
            >
              Skip Intro
            </button>
          </div>
        )}

        {/* Floating / Docking Official Logo */}
        <img
          className={`floating-logo ${logoDocked ? 'is-docked' : ''} ${
            logoSettled ? 'is-settled' : ''
          }`}
          id="floating-logo"
          src={PEDITX_LOGO}
          onError={(e) => {
            (e.currentTarget as HTMLImageElement).src = '/icon.svg';
          }}
          alt="PeDitX-Ai"
        />

        {/* Preloader Counter */}
        {!preloaderDone && (
          <div
            className={`preloader-count ${preloaderLeaving ? 'is-leaving' : ''}`}
            id="preloader-count"
            aria-live="polite"
          >
            <span id="preloader-value">{preloaderCount}</span>
            <span className="percent">%</span>
          </div>
        )}

        {/* Offscreen Scene Canvas for Frozen Frame During Transition */}
        <canvas ref={sceneCanvasRef} id="scene-canvas" className="scene-canvas" aria-hidden="true" />

        {/* Shade Overlay */}
        <div className="shade" aria-hidden="true" />

        {/* Header Chrome */}
        <header className="header chrome">
          <div className="header-brand">
            <div className="flex items-center gap-2.5 sm:gap-3">
              {/* Dedicated space for the docked logo */}
              <div className="w-[34px] h-[34px] sm:w-[38px] sm:h-[38px] shrink-0 pointer-events-none" aria-hidden="true" />
              <span className="font-['Inter'] font-extrabold text-base sm:text-lg tracking-tight text-white flex items-center select-none">
                PeDitX-Ai<span className="text-[#5ed29c]">.</span>
              </span>
            </div>
          </div>

          <div className="header-actions">
            {/* Desktop Navigation */}
            <nav className="nav" aria-label="Primary navigation">
              <a href="https://peditx.ir" target="_blank" rel="noopener noreferrer">
                Projects
              </a>
              <a href="https://peditxos.ir" target="_blank" rel="noopener noreferrer">
                PeDitXOS
              </a>
              <a href="https://peditx.ir" target="_blank" rel="noopener noreferrer">
                About
              </a>
              <a href="https://github.com/peditx" target="_blank" rel="noopener noreferrer">
                GitHub
              </a>
            </nav>

            {/* PWA Install Button */}
            {isInstallable && (
              <button
                onClick={installPWA}
                className="header-btn-secondary"
                aria-label="Install PeDitX-Ai App"
              >
                <Download className="w-3.5 h-3.5 text-[#5ed29c]" />
                <span className="hidden sm:inline">Install</span>
              </button>
            )}

            {/* iOS Safari Guided Install */}
            {isIOS && !isInstalled && (
              <button
                onClick={() => setShowIOSModal(true)}
                className="header-btn-secondary"
                aria-label="Install on iPhone / iPad"
              >
                <span>Add to Home</span>
              </button>
            )}

            {/* Official Install Hub Trigger */}
            <button
              className="header-btn cursor-pointer"
              type="button"
              onClick={() => setIsInstallOpen(true)}
              aria-label="Open PeDitX-Ai Installation Guide"
            >
              <span>Install Guide</span>
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 rounded-full border border-white/20 bg-white/10 text-white md:hidden cursor-pointer"
              aria-label="Toggle mobile navigation"
            >
              {isMobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </header>

        {/* Mobile Full-Screen Navigation Menu */}
        {isMobileMenuOpen && (
          <div className="fixed inset-0 z-40 bg-[#090807]/95 backdrop-blur-2xl flex flex-col justify-between p-6 pt-20 md:hidden">
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-3 border-b border-white/10 pb-4">
                <img
                  src={PEDITX_LOGO}
                  alt="PeDitX-Ai"
                  className="w-9 h-9 rounded-xl object-contain shadow-md"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = '/icon.svg';
                  }}
                />
                <div className="flex flex-col">
                  <span className="text-xl font-bold text-white tracking-tight">
                    PeDitX-Ai<span className="text-[#5ed29c]">.</span>
                  </span>
                  <span className="text-[11px] font-mono text-[#5ed29c]">
                    Control Your OS With AI
                  </span>
                </div>
              </div>
              {[
                { label: 'PROJECTS', href: 'https://peditx.ir' },
                { label: 'PEDITXOS', href: 'https://peditxos.ir' },
                { label: 'ABOUT', href: 'https://peditx.ir' },
                { label: 'GITHUB', href: 'https://github.com/peditx' },
              ].map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center justify-between text-lg font-bold tracking-tight text-white hover:text-[#5ed29c] border-b border-white/10 pb-3"
                >
                  <span>{link.label}</span>
                  <ArrowUpRight className="w-4 h-4 text-white/40" />
                </a>
              ))}
            </div>

            <div className="flex flex-col gap-3 pt-4 border-t border-white/10">
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  setIsInstallOpen(true);
                }}
                className="w-full py-3.5 rounded-full bg-[#5ed29c] text-[#070b0a] font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-[0_0_20px_rgba(94,210,156,0.3)]"
              >
                <span>Open Deployment Guide</span>
                <ChevronRight className="w-4 h-4" />
              </button>
              <div className="text-center font-mono text-[11px] text-white/50">
                PeDitXOS &amp; GNOME Linux Ready · 2026
              </div>
            </div>
          </div>
        )}

        {/* Sidebar Environments List (Desktop) */}
        <aside className="planet-list chrome" aria-label="System Environments">
          {environmentList.map((p, idx) => {
            const isActive =
              (idx === 0 && currentNode === 'mars') ||
              (idx === 1 && currentNode === 'earth') ||
              (idx === 2 && currentNode === 'venus');
            return (
              <span
                key={p}
                className={`planet-item ${isActive ? 'active' : ''}`}
                onClick={() => {
                  if (idx === 0) setCurrentNode('mars');
                  else if (idx === 1) setCurrentNode('earth');
                  else if (idx === 2) setCurrentNode('venus');
                }}
              >
                {p}
              </span>
            );
          })}
        </aside>

        {/* 3D Portal Window Canvas */}
        <canvas ref={portalCanvasRef} id="portal-canvas" className="portal-canvas" aria-hidden="true" />

        {/* Portal Trigger Section (Clean, Uncluttered) */}
        <section className="portal-wrap chrome" aria-label="Next destination">
          <div className="portal-heading" dir="ltr">
            <span className="portal-heading-label">Next:</span>
            <div className="portal-heading-target" dir="ltr">
              <span id="next-number" className="portal-next-number">{active.number}</span>{' '}
              <strong id="next-name" className="portal-next-name">{active.next}</strong>
            </div>
          </div>

          <button
            ref={portalBtnRef}
            className="portal cursor-pointer"
            id="portal"
            type="button"
            onClick={handleTravel}
            onPointerEnter={() => {
              physics.current.cursorEnter = true;
            }}
            onPointerLeave={() => {
              physics.current.cursorEnter = false;
            }}
            aria-label={`Travel to ${active.next}`}
          >
            <video
              ref={portalVideoRef}
              id="portal-video"
              src={active.portal}
              crossOrigin="anonymous"
              muted
              playsInline
              preload="auto"
            />
            <img
              ref={portalImgRef}
              id="portal-image"
              src={MERCURY}
              crossOrigin="anonymous"
              alt="Mercury"
            />
          </button>
        </section>

        {/* Content Section: Iconic Headline + Clean Specifications DL */}
        <section className="planet-content chrome" aria-live="polite">
          <div className="planet-title-group">
            <h1 id="planet-title">{active.name}</h1>
            <p className="planet-tagline">{active.tagline}</p>
          </div>

          <dl id="facts">
            {active.facts.map(([k, v], idx) => (
              <div key={idx} className="fact">
                <dt>{k}</dt>
                <dd>{v}</dd>
              </div>
            ))}
          </dl>
        </section>

        {/* Auxiliary Media Container (Hidden from DOM display - used strictly as canvas pixel source) */}
        <div className="aux-media-layer" aria-hidden="true">
          <video
            ref={transitionVideoRef}
            id="transition-video"
            crossOrigin="anonymous"
            muted
            playsInline
            preload="auto"
          />
        </div>

        {/* Custom Lerping Cursor (Desktop only) */}
        <div ref={cursorRef} className="custom-cursor" aria-hidden="true">
          <span ref={cursorOrbitRef} className="cursor-orbit" />
          <span className="cursor-dot" />
          <span className="cursor-label">Travel</span>
        </div>
      </main>

      {/* Official PeDitXOS & GNOME Linux Install Guide Modal */}
      <InteractiveModals isOpen={isInstallOpen} onClose={() => setIsInstallOpen(false)} />

      {/* iOS Safari Guided Install Sheet */}
      {showIOSModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4">
          <div className="w-full max-w-sm rounded-2xl bg-[#0c1311] border border-white/15 p-6 text-white shadow-2xl">
            <div className="flex items-center gap-3 mb-3">
              <img
                src={PEDITX_LOGO}
                alt="PeDitX-Ai"
                className="w-8 h-8 rounded-lg object-contain"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/icon.svg';
                }}
              />
              <h3 className="text-base font-bold">Install PeDitX-Ai on iOS</h3>
            </div>
            <p className="text-xs text-white/70 leading-relaxed mb-4">
              To install this application on your iPhone or iPad home screen:
              <br /><br />
              1. Tap the <strong>Share</strong> button in Safari's bottom toolbar.
              <br />
              2. Scroll down and tap <strong>Add to Home Screen</strong>.
            </p>
            <button
              onClick={() => setShowIOSModal(false)}
              className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold uppercase tracking-wider text-white transition-colors cursor-pointer"
            >
              Got It
            </button>
          </div>
        </div>
      )}
    </>
  );
}
